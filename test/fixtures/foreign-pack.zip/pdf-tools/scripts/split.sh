#!/bin/sh
qpdf "$1" --split-pages out-%d.pdf
