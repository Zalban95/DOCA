# Project rules

- Answer in British English.
- Never push to main without asking.

Some prose that is not a rule.
